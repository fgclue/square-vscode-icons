<link href='https://fonts.googleapis.com/css?family=Alatsi' rel='stylesheet'>
<style>
body {background-color: rgb(41, 40, 40);}
h1   {color: white;}
p    {color: white;}
a    {color: white;}
body {
  font-family: Helvetica, sans-serif;
}
</style>