<p align=center>
<img src=https://upload.wikimedia.org/wikipedia/commons/9/9a/Visual_Studio_Code_1.35_icon.svg height=auto width=200>
</p>
<p align=center>
square vscode icons
</p>
<p align=center>
i use vscode-icons as my icon pack
</p>
<p align=center>
but, i didnt like it a lot, so well
</p>
<p align=center>
i decided, to make my own icon pack
</p>
<p align=center>
so here it is
</p>
